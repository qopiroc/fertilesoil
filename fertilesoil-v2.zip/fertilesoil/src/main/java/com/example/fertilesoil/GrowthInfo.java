package com.example.fertilesoil;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.FarmBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.Property;

import java.util.Collections;

/**
 * Показывает стадию роста и примерное (ожидаемое) время до созревания.
 * Рост в игре случайный, поэтому время приблизительное.
 */
public final class GrowthInfo {
    private GrowthInfo() {}

    public static void show(Player player, ServerLevel level, BlockPos soilPos) {
        BlockPos plantPos = soilPos.above();
        BlockState plant = level.getBlockState(plantPos);
        IntegerProperty ageProp = findAgeProperty(plant);

        if (ageProp == null || !FertileSoilBlock.isGrowable(plant)) {
            player.displayClientMessage(Component.translatable("message.fertilesoil.growth.none"), true);
            return;
        }

        Component name = plant.getBlock().getName();
        int age = plant.getValue(ageProp);
        int maxAge = Collections.max(ageProp.getPossibleValues());

        if (age >= maxAge) {
            player.displayClientMessage(Component.translatable("message.fertilesoil.growth.ripe", name), true);
            return;
        }
        if (level.getRawBrightness(plantPos, 0) < 9) {
            player.displayClientMessage(Component.translatable("message.fertilesoil.growth.dark", name), true);
            return;
        }

        // Сколько тиков нужно растению при обычной (1x) скорости
        float speed = growthSpeed(level, plantPos, plant);
        double randomTicksPerStage = (int) (25.0F / speed) + 1;
        if (plant.is(Blocks.BEETROOTS)) {
            randomTicksPerStage *= 1.5D; // у свёклы рост срабатывает только в 2/3 случаев
        }
        int randomTickSpeed = Math.max(1, level.getGameRules().getInt(GameRules.RULE_RANDOMTICKING));
        double ticksPerRandomTick = 4096.0D / randomTickSpeed;
        double work = (maxAge - age) * randomTicksPerStage * ticksPerRandomTick;

        long boneTicks = level.getBlockEntity(soilPos) instanceof FertileSoilBlockEntity soil
                ? soil.getRemainingTicks(level.getGameTime()) : 0L;

        double normal = FertileSoilBlock.NORMAL_MULTIPLIER;
        double boosted = FertileSoilBlock.BONE_MEAL_MULTIPLIER;
        double ticks;
        if (boneTicks > 0 && boneTicks * boosted >= work) {
            ticks = work / boosted;
        } else if (boneTicks > 0) {
            ticks = boneTicks + (work - boneTicks * boosted) / normal;
        } else {
            ticks = work / normal;
        }

        long minutes = Math.max(1L, Math.round(ticks / 1200.0D));
        String key = boneTicks > 0 ? "message.fertilesoil.growth.bone" : "message.fertilesoil.growth";
        player.displayClientMessage(Component.translatable(key, name, age + 1, maxAge + 1, minutes), true);
    }

    private static IntegerProperty findAgeProperty(BlockState state) {
        for (Property<?> property : state.getProperties()) {
            if (property instanceof IntegerProperty ip && property.getName().equals("age")) {
                return ip;
            }
        }
        return null;
    }

    /** Та же формула, что у ванильных посевов. Наша земля считается увлажнённой грядкой. */
    private static float growthSpeed(ServerLevel level, BlockPos plantPos, BlockState plant) {
        float f = 1.0F;
        BlockPos below = plantPos.below();
        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                float f1 = 0.0F;
                BlockState soil = level.getBlockState(below.offset(i, 0, j));
                if (soil.getBlock() instanceof FertileSoilBlock) {
                    f1 = 3.0F;
                } else if (soil.is(Blocks.FARMLAND)) {
                    f1 = soil.getValue(FarmBlock.MOISTURE) > 0 ? 3.0F : 1.0F;
                }
                if (i != 0 || j != 0) {
                    f1 /= 4.0F;
                }
                f += f1;
            }
        }

        Block block = plant.getBlock();
        boolean rowX = block == level.getBlockState(plantPos.west()).getBlock()
                || block == level.getBlockState(plantPos.east()).getBlock();
        boolean rowZ = block == level.getBlockState(plantPos.north()).getBlock()
                || block == level.getBlockState(plantPos.south()).getBlock();
        if (rowX && rowZ) {
            f /= 2.0F;
        } else {
            boolean diagonal = block == level.getBlockState(plantPos.north().west()).getBlock()
                    || block == level.getBlockState(plantPos.north().east()).getBlock()
                    || block == level.getBlockState(plantPos.south().west()).getBlock()
                    || block == level.getBlockState(plantPos.south().east()).getBlock();
            if (diagonal) {
                f /= 2.0F;
            }
        }
        return f;
    }
}
